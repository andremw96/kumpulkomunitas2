<?php $__env->startSection('content'); ?>

<section>
  <div class="container">
    <div class="table-responsive">
      <table class="table forum">
        <thead>
        <?php $__currentLoopData = $allSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCate): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <th><h3><a href='<?php echo e(url("forum/$subCate->id")); ?>'><i class="fa fa-comments"></i>   <?php echo e($subCate->category); ?></a></h3></th>
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $subCate->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstNestedSub): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                <td><h5><a href='<?php echo e(url("forum/$firstNestedSub->id")); ?>'><?php echo e($firstNestedSub->category); ?> </a></h5></td>
              </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>        
      </table>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>