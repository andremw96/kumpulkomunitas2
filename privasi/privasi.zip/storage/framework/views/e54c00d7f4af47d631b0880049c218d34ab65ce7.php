<?php $__env->startSection('content'); ?>

<section>
	<div class="container">
		<h4>General Discussion - The Lounge</h4>
		<hr>	

		<div class="panel panel-success">
			<div class="panel-heading">
				<h3 class="panel-title">The Lounge</h3>				
			</div>

			<div class="panel-body">
				<table class="table table-stripped">
				  <thead>
					<tr>
						<th>Topic title</th>
						<th>Created By</th>
						<th>Created At</th>
						<th>Last Post</th>
					</tr>
				  </thead>
				  <tbody>
					<?php $__currentLoopData = $GenDisc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TheL): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<tr>
							<td><h4><a href="<?php echo e(url('content')); ?>"><?php echo e($TheL->title); ?></a></h4></td>
							<td><h4><?php echo e($TheL->username); ?></h4></td>
							<td><h4><?php echo e($TheL->created_at); ?></h4></td>
							<td><h4><?php echo e($TheL->updated_at); ?></h4></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>					
				  </tbody>
				</table>
			</div>
		</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>