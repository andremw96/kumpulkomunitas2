<?php $__env->startSection('title', 'Admin Dashboard | Lihat Daftar Thread'); ?>


<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Dashboard
    <small>Control panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
    <li class="active">Daftar Thread</a></li>
  </ol> 
</section>

<section class="content">
  <div>
      <table class="table">
        <thead>
          <tr>
            <th>Judul</th>
            <th>Username</th>
            <th>Kategori</th>
            <th>Created At</th>
            <th>Updated At</th>
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $thread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dafthread): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>         
              <tr>
              	<td><a href='<?php echo e(route("thread.show", $dafthread->post_id )); ?>' target="_blank"><?php echo e($dafthread->title); ?></a></td>
                <td><a href="<?php echo e(url('/admin/account/' . $dafthread->user_id)); ?>"> <?php echo e($dafthread->username); ?> </a></td>
                <td><?php echo e($dafthread->category); ?></td>
                <td><?php echo e($dafthread->created_at); ?></td>
                <td><?php echo e($dafthread->updated_at); ?></td>                               
              </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
      </table>   
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>