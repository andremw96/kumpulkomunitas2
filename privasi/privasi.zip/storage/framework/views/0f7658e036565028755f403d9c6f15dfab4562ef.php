<?php $__env->startSection('title', 'Admin Dashboard | Edit Kategori'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
	  <h1>
	    Dashboard
	    <small>Control panel</small>
	  </h1>
	  <ol class="breadcrumb">
	    <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
	    <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	    <li><a href="<?php echo e(url('/admin/kategori/DaftarKategori')); ?>">Daftar Kategori</a></li>
	    <li class="active">Edit Kategori</li>
	  </ol> 
</section>

<section class="content">
		<?php if($errors): ?>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<p><?php echo e($error); ?></p>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
	<div class="container col-xs-12">
		<form action="<?php echo e(url('/admin/kategori/' . $IsiCategory->id)); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

						<input type="hidden" name="_method" value="PUT" />
			<input type="hidden" name="updated_by" value=" <?php echo e(Auth::user()->id); ?> ">      
		    <div class="form-group">
		        <label for="Username">Username di Forum : </label>
		        <input type="text" class="form-control" id="Username" value="<?php echo e($CariUsername->username); ?>" required disabled>
		    </div>
		    <div class="form-group <?php if($errors->has('category')): ?> has-error has-feedback <?php endif; ?>">
				<label for="category">Nama Kategori</label>
				<input type="text" class="form-control" name="category" placeholder="Nama Kategori" value="<?php echo e($IsiCategory -> category); ?>">
				<?php if($errors->has('category')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span>
						<?php echo e($errors->first('category')); ?>

					</p>
				<?php endif; ?>
			</div>
			<div class="form-group <?php if($errors->has('parent')): ?> has-error has-feedback <?php endif; ?>">
				<label for="parent">Sub Kategori dari</label>
				<select class="form-control" name="parent">
					<option value=0> Bukan SubCategory </option>					
					<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CariKateg): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<option value=" <?php echo e($CariKateg->id); ?> "> <?php echo e($CariKateg->category); ?> </option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</select>
			</div>
			<div class="form-group <?php if($errors->has('description')): ?> has-error has-feedback <?php endif; ?>">
				<label for="description">Deskripsi Singkat</label>
				<input type="text" class="form-control" name="description" placeholder="Nama Event" value="<?php echo e($IsiCategory->description); ?>">
				<?php if($errors->has('description')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span>
						<?php echo e($errors->first('description')); ?>

					</p>
				<?php endif; ?>
			</div>
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>