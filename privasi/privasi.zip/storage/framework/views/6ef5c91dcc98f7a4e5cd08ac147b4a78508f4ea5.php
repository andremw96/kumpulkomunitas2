<?php $__env->startSection('title', 'Daftar Event'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/calendar')); ?>">Calendar</a></li>
			<li class="active">Events List</li>		
		</ol>
	</div>

	<?php if(Auth::guest()): ?>		
	
	<?php elseif(Auth::user()->HakAkses === 'Admin'): ?>
		<a href="<?php echo e(url('events/create')); ?>" type="submit" button type="button" class="btn btn-primary pull-right">Add new event</a>
	<?php endif; ?>
</div>		

<div class="container">
	<div class="col-lg-12">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>#</th>
					<th>Event's Title</th>
					<th>Komunitas</th>
					<th>Start</th>
					<th>End</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 1;?>
				<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<th scope="row"><?php echo e($i++); ?></th>
					<td><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e($event->title); ?></a></td>
					<td><?php echo e($event->komunitas); ?></td>
					<td><?php echo e(date("g:ia\, jS M Y", strtotime($event->start_time))); ?></td>
					<td><?php echo e(date("g:ia\, jS M Y", strtotime($event->end_time))); ?></td>
					<td>
						<?php if(Auth::guest()): ?> 	
	
						<?php elseif((Auth::id() == $event->user_id) or (Auth::user()->HakAkses === 'Admin')): ?>		
							<a class="btn btn-primary btn-xs" href="<?php echo e(url('events/' . $event->id . '/edit')); ?>">
							<span class="glyphicon glyphicon-edit"></span> Edit</a>
							<form action="<?php echo e(url('events/' . $event->id)); ?>" style="display:inline" method="POST">
								<input type="hidden" name="_method" value="DELETE" />
								<?php echo e(csrf_field()); ?>


								<button onclick="return confirm('Anda yakin akan menghapus Agenda ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Delete</button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>