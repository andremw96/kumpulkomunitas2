<?php $__env->startSection('title', 'Admin Dashboard | Lihat Daftar Request Komunitas'); ?>


<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Dashboard
    <small>Control panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
    <li class="active">Daftar Request</a></li>
  </ol> 
</section>

<section class="content">
  <div>
      <table class="table">
        <thead>
          <tr>
            <th>Username</th>
            <th>Nama Komunitas</th>
            <th>Deskripsi</th>
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $request; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dafrequest): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <?php if( $dafrequest->disetujui === 0 ): ?>
              <tr>
                <td><a href="<?php echo e(url('/admin/account/' . $dafrequest->user_id)); ?>"> <?php echo e($dafrequest->username); ?> </a></td>
                <td><a href="<?php echo e(url('admin/request/'. $dafrequest->id)); ?> "> <?php echo e($dafrequest->namaKomunitas); ?> </a></td>
                <td> <?php echo e($dafrequest->deskipsi); ?> </td> 
                <?php if( $dafrequest->disetujui === 0 ): ?>               
                  <td>
                      <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/request/create/' .$dafrequest->id)); ?>"><span class="glyphicon glyphicon-edit"></span> Buatkan Thread</a>
                      <form action="<?php echo e(url('/admin/request/' . $dafrequest->id)); ?>" style="display:inline" method="POST">
                          <input type="hidden" name="_method" value="DELETE" />
                          <?php echo e(csrf_field()); ?>


                          <button onclick="return confirm('Anda yakin akan menolak request ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Tolak</button>
                      </form>
                  </td>
                <?php endif; ?>
              </tr>
            <?php elseif( $dafrequest->disetujui === 1 ): ?>
              <tr class="success">
                <td><a href="<?php echo e(url('/admin/account/' . $dafrequest->user_id)); ?>"> <?php echo e($dafrequest->username); ?> </a></td>
                <td><a href=" <?php echo e(url('admin/request/'. $dafrequest->id)); ?> "><?php echo e($dafrequest->namaKomunitas); ?> </a></td>
                <td> <?php echo e($dafrequest->deskipsi); ?> </td> 
                <?php if( $dafrequest->disetujui === 0 ): ?>               
                  <td>
                      <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/request/create/' .$dafrequest->id)); ?>"><span class="glyphicon glyphicon-edit"></span> Buatkan Thread</a>
                      <form action="<?php echo e(url('/admin/request/' . $dafrequest->id)); ?>" style="display:inline" method="POST">
                          <input type="hidden" name="_method" value="DELETE" />
                          <?php echo e(csrf_field()); ?>


                          <button onclick="return confirm('Anda yakin akan menolak request ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Tolak</button>
                      </form>
                  </td>
                <?php else: ?>
                  <td></td>
                <?php endif; ?>
              </tr>
            <?php else: ?>
              <tr class="danger">
                <td><a href="<?php echo e(url('/admin/account/' . $dafrequest->user_id)); ?>"> <?php echo e($dafrequest->username); ?> </a></td>
                <td><a href=" <?php echo e(url('admin/request/'. $dafrequest->id)); ?> "> <?php echo e($dafrequest->namaKomunitas); ?> </a></td>
                <td> <?php echo e($dafrequest->deskipsi); ?> </td> 
                <?php if( $dafrequest->disetujui === 0 ): ?>               
                  <td>
                      <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/request/create/' .$dafrequest->id)); ?>"><span class="glyphicon glyphicon-edit"></span> Buatkan Thread</a>
                      <form action="<?php echo e(url('/admin/request/' . $dafrequest->id)); ?>" style="display:inline" method="POST">
                          <input type="hidden" name="_method" value="DELETE" />
                          <?php echo e(csrf_field()); ?>


                          <button onclick="return confirm('Anda yakin akan menolak request ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Tolak</button>
                      </form>
                  </td>
                <?php endif; ?>
              </tr>
            <?php endif; ?>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
      </table>   
            <?php echo e($request->links()); ?> 
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>