<?php $__env->startSection('title', 'Edit Event'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/events')); ?>">Events</a></li>
			<li class="active">Edit - <?php echo e($event->title); ?></li>
		</ol>
	</div>
</div>

<div class="container">
	<div class="col-lg-6">
		
		<?php if($errors): ?>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<p><?php echo e($error); ?></p>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php endif; ?>
		
		<form action="<?php echo e(url('events/' . $event->id)); ?>" method="POST">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="_method" value="PUT" />
			<input type="hidden" name="updated_by" value=" <?php echo e(Auth::user()->id); ?> "> 
			<input type="hidden" name="userid" value="<?php echo e($event->user_id); ?>">
			<div class="form-group">
		        <label for="Username">Username di Forum : </label>
		        <input type="text" class="form-control" id="Username" value="<?php echo e($CariUsername->username); ?>" required disabled>
	    	</div>		
	    	<div class="form-group <?php if($errors->has('komunitas')): ?> has-error has-feedback <?php endif; ?>">
				<label for="komunitas">Untuk Komunitas <?php echo e($event->komunitas); ?></label>
				<input type="text" class="form-control" name="komunitas" placeholder="Nama Komunitas" value="<?php echo e($event->komunitas); ?>">
				<?php if($errors->has('komunitas')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span>
						<?php echo e($errors->first('komunitas')); ?>

					</p>
				<?php endif; ?>
			</div>		
			<div class="form-group <?php if($errors->has('title')): ?> has-error has-feedback <?php endif; ?>">
				<label for="title">Title</label>
				<input type="text" class="form-control" name="title" value="<?php echo e($event->title); ?>" placeholder="E.g. My event's title">
				<?php if($errors->has('title')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span> 
					<?php echo e($errors->first('title')); ?>

					</p>
				<?php endif; ?>
			</div>
			<div class="form-group <?php if($errors->has('time')): ?> has-error <?php endif; ?>">
				<label for="time">Time</label>
				<div class="input-group">
					<input type="text" class="form-control" name="time" value="<?php echo e($event->start_time . ' - ' . $event->end_time); ?>" placeholder="Select your time">
					<span class="input-group-addon">
						<span class="glyphicon glyphicon-calendar"></span>
                    </span>
				</div>
				<?php if($errors->has('time')): ?>
					<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span> 
					<?php echo e($errors->first('time')); ?>

					</p>
				<?php endif; ?>
			</div>
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>		
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('_asset/js')); ?>/daterangepicker.js"></script>
<script type="text/javascript">
$(function () {
	$('input[name="time"]').daterangepicker({
		"timePicker": true,
		"timePicker24Hour": true,
		"timePickerIncrement": 15,
		"autoApply": true,
		"locale": {
			"format": "DD/MM/YYYY HH:mm:ss",
			"separator": " - ",
		}
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>