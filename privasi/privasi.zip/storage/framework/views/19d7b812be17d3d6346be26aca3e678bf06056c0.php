<?php $__env->startSection('title', 'Detail Pesan Masuk'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/message/inbox')); ?>">List Pesan Masuk</a></li>
			<li class="active"><?php echo e($message->title); ?></li>
		</ol>
	</div>
</div>

<div class="container">
	<div class="col-lg-12">
		<h2><?php echo e($message->title); ?></h2>
		<h5>Pengirim : <?php echo e($CariUsername->username); ?></h5>
		<hr>
	</div>
</div>

<div class="container">
	<p class="well"><?php echo e($message->isi); ?></p>
	<a class="btn btn-primary pull-right" href="<?php echo e(url('/message/balaspesan/' . $message->user_id_pengirim)); ?>"><span class="glyphicon glyphicon-edit"></span> Balas</a> 
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>