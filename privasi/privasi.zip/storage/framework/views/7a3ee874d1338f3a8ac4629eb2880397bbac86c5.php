<?php $__env->startSection('title', 'Balas Pesan'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">           
    <hr>
    <form method="POST" action="<?php echo e(route('message.store')); ?>">   
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="userid_pengirim" value="<?php echo e(Auth::user()->id); ?>">                   
        <label>Penerima</label>
        <select name="userid_penerima" class="form-control">
              <option value="<?php echo e($User->id); ?>"><?php echo e($User->username); ?></option>
        </select>
        <label>Judul</label>
          <input type="text" class="form-control" name="title" required>
        <label>Isi</label>
          <textarea name="isi" class="form-control" rows="10" required></textarea>
        <br>
        <input type="submit" class="btn btn-success pull-right" value="Kirim Pesan">
    </form><br>
    <hr>
    <a href="" class="pull-right">Keluar</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>