<?php $__env->startSection('title', 'Calendar'); ?>
<?php $__env->startSection('content'); ?>

	<?php echo $calendar->calendar(); ?>

    <?php echo $calendar->script(); ?>

	<!--	<div id='external-events'>
			<h4>Draggable Events</h4>
			<div class='fc-event'>New Event</div>
			<p>
				<img src="assets/img/trashcan.png" id="trash" alt="">
			</p>
		</div>

		<div id='calendar'></div>

		<div style='clear:both'></div>

		 <xspan class="tt">x</xspan> -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>