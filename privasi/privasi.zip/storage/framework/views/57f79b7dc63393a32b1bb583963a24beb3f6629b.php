<?php $__currentLoopData = $IsiThread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $JudulThread): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<?php $__env->startSection('title', $JudulThread->title); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<?php $__currentLoopData = $CariKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CariK): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li><a href='<?php echo e(url("forum/$CariK->id")); ?>'><?php echo e($CariK->category); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

			<?php $__currentLoopData = $IsiThread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $JudulThread): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	         	<li class="active"><?php echo e($JudulThread->title); ?></li>	
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ol>
	</div>
</div>	

<div class="container">
	<div class="panel panel-success">
		<div class="panel-heading">
			 <?php $__currentLoopData = $CariKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CariK): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			 	<label>Topic Category : <a href='<?php echo e(url("forum/$CariK->id")); ?>'> <?php echo e($CariK->category); ?> </a></label>
			 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

			 <?php $__currentLoopData = $IsiThread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $JudulThread): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	         
	         	<?php if(Auth::guest()): ?>		
			
				<?php elseif(Auth::id() === $JudulThread->user_id): ?>				
				   <a href="<?php echo e(url('events/create')); ?>" type="submit" button type="button" class="btn btn-primary btn-xs pull-right">Buat Agenda Pertemuan</a>
				<?php endif; ?>
				<h3 class="panel-title">Judul Thread : <?php echo e($JudulThread->title); ?> </h3>
	         <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	    </div> 
	    
	    <div class="panel-body">
	    	<?php $__currentLoopData = $IsiThread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Isi): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>   
	       		<label>Posted By: <?php echo e($Isi -> username); ?> </label>    	
	       		<label>Date time posted : <?php echo e($Isi -> updated_at); ?> </label>		       		
		        <p class='well'><?php echo e($Isi -> content); ?></p>		        
		        <?php if(Auth::guest()): ?>

		        <?php elseif((Auth::id() === $Isi->user_id)	or (Auth::user()->HakAkses === 'Admin')): ?>
		        	<a href="<?php echo e(route('thread.edit', $Isi->post_id)); ?>" type="submit" button type="button" class="btn btn-info btn-xs pull-right">Edit Thread</a>
		        <?php else: ?>

		        <?php endif; ?>		

		        <?php if(Auth::guest()): ?>

		        <?php elseif(Auth::user()->HakAkses === 'Admin'): ?>
		        	<form method="POST" action="<?php echo e(route('thread.destroy', $Isi->post_id)); ?>" accept-charset="UTF-8">	
		        	<?php echo e(csrf_field()); ?>

		        		<input name="_method" type="hidden" value="DELETE">		        		
		        		<input onclick="return confirm('Anda yakin akan menghapus thread ?');" type="submit" button type="button" class="btn btn-danger btn-xs pull-right" value="Delete Thread" />
		        	</form>
		        <?php else: ?>

		        <?php endif; ?>        
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	       <br>
	       <hr>
	       <div id="comments">
	       	  <?php $__currentLoopData = $IsiComment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$IsiC): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	       		<label>Comment # <?php echo e(++$key); ?> by : </label> <?php echo e($IsiC -> username); ?> <br>
                <h6 class="pull-right"> <?php echo e($IsiC -> updated_at); ?> </h6>
                <p class='well'> <?php echo e($IsiC -> comment); ?> </p>
                
	            <?php if(Auth::guest()): ?>

		        <?php elseif((Auth::id() === $IsiC->user_id) or (Auth::user()->HakAkses === 'Admin')): ?>	
		        	<a href="<?php echo e(route('comment.edit', $IsiC->comment_id)); ?>" type="submit" button type="button" class="btn btn-info btn-xs pull-right">Edit Comment</a>
		        <?php endif; ?>	 

		        <?php if(Auth::guest()): ?>

		        <?php elseif(Auth::user()->HakAkses === 'Admin'): ?>
		        	<form method="POST" action="<?php echo e(route('comment.destroy', $IsiC->comment_id)); ?>" accept-charset="UTF-8">	
		        	<?php echo e(csrf_field()); ?>	
		        		<input name="_method" type="hidden" value="DELETE">		        		
		        		<input onclick="return confirm('Anda yakin akan menghapus Comment ?');" type="submit" button type="button" class="btn btn-danger btn-xs pull-right" value="Delete Comment" />
		        	</form>
		        <?php endif; ?>   
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	       </div>
	    </div>

	     <?php if(Auth::guest()): ?>
	     	<div class="col-sm-5 col-md-5 sidebar">
				 <h3>Komentar?? <a href="<?php echo e(url('/login')); ?>">Login Dulu..!!</a></h3>
			      <form> 
				        <textarea type="text" class="form-control" name="commenttxt" rows="5"></textarea><br>
				        <input type="submit" id="save" class="btn btn-success pull-right" value="Tambahkan Komentar">
			      </form>
		    </div>
	     <?php else: ?>
		    <div class="col-sm-5 col-md-5 sidebar">
				 <h3>Komentar</h3>
			      <form method="POST" action="<?php echo e(route('comment.store')); ?>">
			      	<?php echo e(csrf_field()); ?>  
				        <textarea type="text" class="form-control" name="commenttxt" rows="5" required></textarea><br>
				        <?php $__currentLoopData = $IsiThread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Cari): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				        	<input type="hidden" name="postid" value="<?php echo e($Cari -> post_id); ?>">
				        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		            	<input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">
		            	<input type="hidden" name="username_id" value="<?php echo e(Auth::user()->username); ?>">
				        <input type="submit" id="save" class="btn btn-success pull-right" value="Tambahkan Komentar">
			      </form>
		    </div>
		<?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>