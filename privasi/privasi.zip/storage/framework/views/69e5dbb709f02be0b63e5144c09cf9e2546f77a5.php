<?php $__env->startSection('content'); ?>

<section>
	<div class="container">
		<h4>General Discussion</h4>
		<hr>	

		<div class="panel panel-success">
			<div class="panel-heading">
				<h3 class="panel-title">General Discussion</h3>				
			</div>

			<div class="panel-body">
				<table class="table table-stripped">
					<tr>
						<th>Topic title</th>
						<th>Created By</th>
						<th>Created At</th>
						<th>Last Post</th>
					</tr>
					<?php
						$host = "localhost";
						$user = "root";
						$pwd  = "";
						$db   = "kumpulkomunitas";
						$con = mysqli_connect($host,$user,$pwd,$db) or die("Could not connect");
						//mysqli_select_db($db,$con) or die("No database");	
											
						$sel1 = mysqli_query($con, "SELECT * from tblpost where category_id='1'");
	                    while($row1=mysqli_fetch_assoc($sel1)){
	                        extract($row1);
	                        echo '<tr>';
	                        echo '<td><a href="#">'.$title.'</a></td>';
	                        echo '<td>'.$user_id.'</td>';
	                        echo '<td>'.$created_at.'</td>';
	                        echo '<td>'.$updated_at.'</td>';
	                        echo '</tr>';
	                    }
	                ?>
				</table>
			</div>
		</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>