<?php $__env->startSection('title', 'Buat Agenda'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/calendar')); ?>">Calendar</a></li>
			<li class="active">Create Event</li>		
		</ol>
	</div>
</div>	

<div class="container">
	<form action="<?php echo e(url('/simpanagenda')); ?>" method="POST">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">		     
	    <div class="form-group">
	        <label for="Username">Username di Forum : </label>
	        <input type="text" class="form-control" id="Username" value="<?php echo e(Auth::user()->username); ?>" required disabled>
	    </div>
	    <input type="hidden" name="postid" value="<?php echo e($thread->post_id); ?>">	
	    <div class="form-group <?php if($errors->has('komunitas')): ?> has-error has-feedback <?php endif; ?>">
			<label for="komunitas">Untuk Komunitas</label>
			<input type="text" class="form-control" name="komunitas" placeholder="Nama Komunitas" value="<?php echo e($thread->title); ?>">
			<?php if($errors->has('komunitas')): ?>
				<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span>
					<?php echo e($errors->first('komunitas')); ?>

				</p>
			<?php endif; ?>
		</div>
		<div class="form-group <?php if($errors->has('title')): ?> has-error has-feedback <?php endif; ?>">
			<label for="title">Title</label>
			<input type="text" class="form-control" name="title" placeholder="Nama Event" value="<?php echo e(old('title')); ?>">
			<?php if($errors->has('title')): ?>
				<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span>
					<?php echo e($errors->first('title')); ?>

				</p>
			<?php endif; ?>
		</div>
		<div class="form-group <?php if($errors->has('time')): ?> has-error <?php endif; ?>">
			<label for="time">Time</label>
			<div class="input-group">
				<input type="text" class="form-control" name="time" placeholder="Select your time" value="<?php echo e(old('time')); ?>">
				<span class="input-group-addon">
					<span class="glyphicon glyphicon-calendar"></span>
				</span>
			</div>
			<?php if($errors->has('time')): ?>
				<p class="help-block"><span class="glyphicon glyphicon-exclamation-sign"></span>
					<?php echo e($errors->first('time')); ?>

				</p>
			<?php endif; ?>
		</div>
		<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('assets/js')); ?>/daterangepicker.js"></script>
	<script type="text/javascript">
		$(function () {
			$('input[name="time"]').daterangepicker({
				"minDate": moment('<?php echo date('Y-m-d G')?>'),
				"timePicker": true,
				"timePicker24Hour": true,
				"timePickerIncrement": 15,
				"autoApply": true,
				"locale": {
					"format": "YYYY-MM-DD HH:mm:ss",
					"separator": " - ",
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>