<?php $__env->startSection('title', 'Admin Dashboard | Lihat Daftar Account'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Dashboard
    <small>Control panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
    <li class="active">Daftar Account</li>
  </ol> 
</section>

<section class="content">
  <div>
  <a href="<?php echo e(url('/admin/account/create')); ?>" type="submit" button type="button" class="btn btn-primary pull-right">Add new Account</a>
      <table class="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Username</th>
            <th>HakAkses</th>        
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftaraccount): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                <td><a href="<?php echo e(url('/admin/account/' . $daftaraccount->id)); ?>"><?php echo e($daftaraccount->id); ?></a></td>
                <td><a href="<?php echo e(url('/admin/account/' . $daftaraccount->id)); ?>"> <?php echo e($daftaraccount->name); ?></a></td>
                <td> <?php echo e($daftaraccount->username); ?> </td>
                <td> <?php echo e($daftaraccount->HakAkses); ?> </td>
                <td>
                    <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/account/' . $daftaraccount->id . '/edit')); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                    <form action="<?php echo e(url('/admin/account/' . $daftaraccount->id)); ?>" style="display:inline" method="POST">
                        <input type="hidden" name="_method" value="DELETE" />
                        <?php echo e(csrf_field()); ?>


                        <button onclick="return confirm('Anda yakin akan menghapus Account ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Delete</button>
                    </form>
                </td>
              </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
      </table>
        <?php echo e($account->links()); ?>

   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>