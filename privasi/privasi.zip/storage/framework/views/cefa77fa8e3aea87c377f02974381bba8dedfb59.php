<?php $__env->startSection('title', 'Admin Dashboard | Lihat Daftar Kategori'); ?>


<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Dashboard
    <small>Control panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
    <li class="active">Daftar Kategori</li>
  </ol> 
</section>

<section>
  <div>
      <table class="table">
        <thead>
          <tr>
            <th>Kategori</th>
            <th>Topics</th>
            <th>Posts</th>
            <th>Last Post</th>
            <th>Aksi</th>
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstNestedSub): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                <td><a href='<?php echo e(url("forum/$firstNestedSub->id")); ?>'><?php echo e($firstNestedSub->category); ?> </a></h5></td>
                <td> <?php echo e($firstNestedSub->JmlhPost); ?> </td>
                <td> <?php echo e($firstNestedSub->JmlhComment); ?> </td>
                <td> <?php echo e($firstNestedSub->LastPost); ?> </td>
                <td><a href="#"><button class="btn btn-default">Edit</button></a> <a href="#"><button class="btn btn-danger">Delete</button></a></td>
              </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>        
      </table>
   </div>
	<a href="add-category.php" class="pull-right btn btn-success">Tambah Baru</a><br><br>		
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>