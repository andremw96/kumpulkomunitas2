<?php $__env->startSection('title', 'Daftar Pesan'); ?>

<?php $__env->startSection('content'); ?>	
<div class="container">
	<div class="col-lg-12">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>#</th>
					<th>Penerima</th>
					<th>Judul</th>
					<th>created_at</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 1;?>
				<?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Listmessage): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<th scope="row"><?php echo e($i++); ?></th>
					<td><a href="<?php echo e(url('events/' . $Listmessage->id)); ?>"><?php echo e($Listmessage->user_id_penerima); ?></a></td>
					<td><?php echo e($Listmessage->title); ?></td>
					<td><?php echo e($Listmessage->created_at); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>