<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<section>
    <div class="container">
      <!-- Main component for a primary marketing message or call to action -->
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
          <div class="item active">
            <img src="img/community.jpg" alt="Community">
            <div class="carousel-caption">
              <h3>Community</h3>
              <p>My Community</p>
            </div>
          </div>

          <div class="item">
            <img src="img/community2.jpg" alt="Community2">
            <div class="carousel-caption">
              <h3>Community</h3>
              <p>My Community</p>
            </div>
          </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>

    </div>
    </div> <!-- /container -->

    <div class="container">
    <div class="page-header page-heading">
      <ol class="breadcrumb pull-left where-am-i">
        <li><a href="#">FAQ</a></li>
        <li><a href="<?php echo e(url('calendar')); ?>">Calendar</a></li>
      </ol>      

      <ol>
        <div class="col-lg-3" style="margin-left: 66%">
            <div class="input-group">
              <input type="text" class="form-control" aria-label="..." placeholder="Cari..">
              <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><img src="img/cari.png"></button>
              </span>
            </div>
          </div>
      </ol>
      <div class="clearfix"></div> 
    </div>

    <div class="table-responsive">
      <table class="table forum">
        <thead>
        <?php $__currentLoopData = $allSubCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCate): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <th><h3><a href='<?php echo e(url("forum/$subCate->id")); ?>'><i class="fa fa-comments"></i>   <?php echo e($subCate->category); ?></a></h3></th>
            <th class="cell-stat text-center hidden-xs hidden-sm">Topics</th>
            <th class="cell-stat text-center hidden-xs hidden-sm">Posts</th>
            <th class="cell-stat-2x hidden-xs hidden-sm">Last Post</th>
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $subCate->subCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstNestedSub): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                <td>
                <h4><a href='<?php echo e(url("forum/$firstNestedSub->id")); ?>'><?php echo e($firstNestedSub->category); ?> </a><br><small><?php echo e($firstNestedSub->description); ?></small></h4>
                </td>
                <td class="text-center hidden-xs hidden-sm"> - </td>
                <td class="text-center hidden-xs hidden-sm"> - </td>
                <td class="hidden-xs hidden-sm">by <a href="#"> - </a></td>
              </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>        
      </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>