<?php $__env->startSection('title', 'Admin Dashboard | Lihat Daftar Kategori'); ?>


<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Dashboard
    <small>Control panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
    <li class="active">Daftar Kategori</li>
  </ol> 
</section>

<section class="content">
  <div>
  <a href="<?php echo e(url('/admin/kategori/create')); ?>" type="submit" button type="button" class="btn btn-primary pull-right">Add new Category</a>
      <table class="table">
        <thead>
          <tr>
            <th>Kategori</th>
            <th>Topics</th>
            <th>Posts</th>
            <th>Last Post</th>
            <th>Aksi</th>
          </tr>
        </thead>
          <tbody>
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $firstNestedSub): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <tr>
                <td><h5><a href='<?php echo e(url("forum/$firstNestedSub->id")); ?>' target="_blank"><?php echo e($firstNestedSub->category); ?> </a></h5></td>
                <td> <?php echo e($firstNestedSub->JmlhPost); ?> </td>
                <td> <?php echo e($firstNestedSub->JmlhComment); ?> </td>
                <td> <?php echo e($firstNestedSub->LastPost); ?> </td>
                <td>
                    <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/kategori/' . $firstNestedSub->id . '/edit')); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                    <form action="<?php echo e(url('/admin/kategori/' . $firstNestedSub->id)); ?>" style="display:inline" method="POST">
                        <input type="hidden" name="_method" value="DELETE" />
                        <?php echo e(csrf_field()); ?>


                        <button onclick="return confirm('Anda yakin akan menghapus Kategori ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Delete</button>
                    </form>
                </td>
              </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>   
      </table>
    <?php echo e($category->links()); ?>    
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>