<?php $__env->startSection('title', 'Detail Event'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/calendar')); ?>">Calendar</a></li>
			<li><a href="<?php echo e(url('/events')); ?>">Events List</a></li>
			<li class="active"><?php echo e($event->title); ?></li>
		</ol>
	</div>
</div>

<div class="container">
	<div class="col-lg-12">
		<h2><?php echo e($event->title); ?> - <?php echo e($event->komunitas); ?> <small>made by <?php echo e($CariUsername->username); ?></small></h2>
		<hr>
	</div>
</div>

<div class="container">
	<div class="col-lg-6">
		
		<p>Time: <br>
		<?php echo e(date("g:ia\, jS M Y", strtotime($event->start_time)) . ' until ' . date("g:ia\, jS M Y", strtotime($event->end_time))); ?>

		</p>
		
		<p>Duration: <br>
		<?php echo e($duration); ?>

		</p>
		
		<p>						
			<?php if(Auth::guest()): ?> 	
	
			<?php elseif((Auth::id() == $event->user_id) or (Auth::user()->HakAkses === 'Admin')): ?>	
				<form action="<?php echo e(url('events/' . $event->id)); ?>" style="display:inline;" method="POST">
					<input type="hidden" name="_method" value="DELETE" />
					<?php echo e(csrf_field()); ?>

					<button onclick="return confirm('Anda yakin akan menghapus Agenda ini ?');" class="btn btn-danger" type="submit"><span class="glyphicon glyphicon-trash"></span> Delete</button>
				</form>
				<a class="btn btn-primary" href="<?php echo e(url('events/' . $event->id . '/edit')); ?>">
					<span class="glyphicon glyphicon-edit"></span> Edit</a> 
			<?php endif; ?>
			
		</p>
		
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('_asset/js')); ?>/daterangepicker.js"></script>
<script type="text/javascript">
$(function () {
	$('input[name="time"]').daterangepicker({
		"timePicker": true,
		"timePicker24Hour": true,
		"timePickerIncrement": 15,
		"autoApply": true,
		"locale": {
			"format": "DD/MM/YYYY HH:mm:ss",
			"separator": " - ",
		}
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>