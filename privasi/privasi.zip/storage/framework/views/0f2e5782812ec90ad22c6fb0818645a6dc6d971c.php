<?php $__env->startSection('title', 'Request Komunitas'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
       <h2>Form untuk Daftar Komunitas</h2>

       <form method="POST" action="<?php echo e(url('/simpanrequest')); ?>">
       <?php echo e(csrf_field()); ?>  
          <input type="hidden" name="userid" value="<?php echo e(Auth::user()->id); ?>">
          <div class="form-group">          
            <label for="Nama">Nama : </label>
            <input type="text" class="form-control" id="Nama" value="<?php echo e(Auth::user()->name); ?> " required disabled>
          </div>
          <div class="form-group">
            <label for="Username">Username di Forum : </label>
            <input type="text" class="form-control" id="Username" value="<?php echo e(Auth::user()->username); ?>" required disabled>
          </div>
          <div class="form-group">
            <label for="Kategori">Nama Komunitas yang diinginkan : </label>
            <input type="text" class="form-control" id="Kategori" name="namaKomunitas" required autofocus>
          </div>
          <div class="form-group">
            <label for="comment">Deskripsi tentang Komunitas : </label>
            <textarea class="form-control" rows="10" id="comment" name="deskipsi" required></textarea>
          </div>

          <button type="submit" class="btn btn-success btn-block btn-lg">Submit</button>
       </form>
    </div> <!-- /container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>