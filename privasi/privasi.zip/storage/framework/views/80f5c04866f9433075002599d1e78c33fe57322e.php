<?php $__currentLoopData = $namaKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kategori): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	
	<?php $__env->startSection('title', $Kategori->category); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<?php $__currentLoopData = $namaKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kategori): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	         	<li class="active"><?php echo e($Kategori->category); ?></li>	
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ol>
	</div>
</div>	

<section>
	<div class="container">
<?php echo $GenDisc->render(); ?>

		<div class="panel panel-success">
			<div class="panel-heading">
			  <?php $__currentLoopData = $namaKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kategori): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>	
				<h3 class="panel-title"><?php echo e($Kategori->category); ?></h3>		

			</div>

			<div class="panel-body">
				<table class="table table-stripped">
				  <thead>
					<tr>
						<th>Topic title</th>
						<th>Created By</th>
						<th>Created At</th>
						<th>Last Post</th>
					</tr>
				  </thead>
				  <tbody>
					<?php $__currentLoopData = $GenDisc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GenDiscus): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>					
						<tr>
							<td><h4><a href='<?php echo e(route("thread.show", $GenDiscus->post_id )); ?>'><?php echo e($GenDiscus->title); ?></a></h4></td>
							<td><h4><?php echo e($GenDiscus->username); ?></h4></td>
							<td><h4><?php echo e($GenDiscus->created_at); ?></h4></td>
							<td><h4><?php echo e($GenDiscus->updated_at); ?></h4></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>	
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>			  				
				  </tbody>
				</table>
			</div>
		</div>
	</div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>