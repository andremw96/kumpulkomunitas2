<?php $__env->startSection('title', 'Calendar'); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div clss="col-lg-12">
			<ol class="breadcrumb">
				<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
				<li class="active">Calendar</li>		
			</ol>
		</div>
		<?php if((Auth::guest()) or (Auth::user()->HakAkses === 'User')): ?>		
			<a href="<?php echo e(url('events')); ?>" type="submit" button type="button" class="btn btn-primary pull-left">Events List</a>	
		<?php elseif(Auth::user()->HakAkses === 'Admin'): ?>
			<a href="<?php echo e(url('events/create')); ?>" type="submit" button type="button" class="btn btn-primary pull-right">Add new event</a>
			<a href="<?php echo e(url('events')); ?>" type="submit" button type="button" class="btn btn-primary pull-left">Events List</a>	
		<?php endif; ?>
	</div>

	<hr>

	<div class="container">
		<div class="col-lg-12">
			<div id='calendar'></div>
		</div>		
	</div>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script src=<?php echo e(asset('assets/js/fullcalendar.min.js')); ?>></script>
	<script type="text/javascript">
		$(document).ready(function() {
		
		var base_url = '<?php echo e(url('/')); ?>';

		$('#calendar').fullCalendar({
			weekends: true,
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},

			eventLimit: true, // allow "more" link when too many events
			events: {
				url: base_url + '/api',
				error: function() {
					alert("cannot load json");
				}
			}
		});
	});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>