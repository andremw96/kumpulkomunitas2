<?php $__env->startSection('title', 'Edit Thread'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<?php $__currentLoopData = $CariKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CariK): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li><a href='<?php echo e(url("forum/$CariK->id")); ?>'><?php echo e($CariK->category); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

	         	<li><a href='<?php echo e(route("thread.show", $IsiThread->post_id )); ?>'><?php echo e($IsiThread->title); ?> </a></li>	
	        <li class="active">Edit Thread</li>
		</ol>
	</div>
</div>

<section>
	<div class="container">
		<h3>Edit Thread</h3>		
		<div class="panel panel-success">
			<div class="panel-heading">
				 <?php $__currentLoopData = $CariKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CariK): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				 	<label>Topic Category : <a href='<?php echo e(url("forum/$CariK->id")); ?>'> <?php echo e($CariK->category); ?> </a></label>
				 <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				 
		         <h3 class="panel-title">Judul Thread : <a href='<?php echo e(route("thread.show", $IsiThread->post_id )); ?>'><?php echo e($IsiThread->title); ?> </a></h3>		         
		    </div> 

		    <div class="panel-body">   
		    	<form method="POST" action="<?php echo e(route('thread.update', $IsiThread->post_id)); ?>">	
		    		<?php echo csrf_field(); ?>

     				<input type="hidden" name="_method" value="PUT">	
     				<input type="hidden" name="updated_by" value=" <?php echo e(Auth::user()->id); ?> ">
					<textarea class="form-control" name="content" rows="10" required> <?php echo e($IsiThread -> content); ?> </textarea><br>
					<input type="submit" id="save" class="btn btn-success pull-right" value="Edit Thread">					
		    	</form>		        
		       <hr>
		    </div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>