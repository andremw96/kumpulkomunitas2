<?php $__env->startSection('title', 'Admin Dashboard | Lihat Request'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    Dashboard
    <small>Control panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
    <li><a href="<?php echo e(url('/admin/request/DaftarRequest')); ?>">Daftar Request</a></li>
    <li class="active">Lihat Request</li>
  </ol> 
</section>

<section class="content">
	<div class="col-lg-12">
		<h2>ID = <?php echo e($IsiRequest->id); ?></h2>
		<h2>Username = <?php echo e($CariUsername->username); ?></h2>
		<h2>Nama Komunitas = <?php echo e($IsiRequest->namaKomunitas); ?></h2>
		<h2>Deskripsi = <?php echo e($IsiRequest->deskipsi); ?> </h2>
		<hr>
	</div>
	<?php if( $IsiRequest->disetujui === 0 ): ?> 
		 <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/request/create/' .$IsiRequest->id)); ?>"><span class="glyphicon glyphicon-edit"></span> Buatkan Thread</a>
		 <form action="<?php echo e(url('/admin/request/' . $IsiRequest->id)); ?>" style="display:inline" method="POST">
		    <input type="hidden" name="_method" value="DELETE" />
		    <?php echo e(csrf_field()); ?>


		    <button onclick="return confirm('Anda yakin akan menghapus Account ini ?');" class="btn btn-danger btn-xs" type="submit"><span class="glyphicon glyphicon-trash"></span> Tolak</button>
		 </form>
	<?php elseif( $IsiRequest->disetujui === 1 ): ?> 
		 <h4>Request ini sudah dibuatkan thread, <a href='<?php echo e(route("thread.show", $IsiRequest->post_id )); ?>' target="_blank">bisa lihat disini</a></h4>
	<?php else: ?>
		 <h4>Request ini telah ditolak, <a class="btn btn-primary btn-xs" href="<?php echo e(url('/admin/request/create/' .$IsiRequest->id)); ?>"><span class="glyphicon glyphicon-edit"></span> Buatkan Thread</a></h4>
	<?php endif; ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>