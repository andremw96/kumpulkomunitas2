<?php $__env->startSection('title', 'Daftar Pesan Masuk'); ?>

<?php $__env->startSection('content'); ?>	
<div class="container">
	<div clss="col-lg-12">
		<ol class="breadcrumb">
			<li>You are here: <a href="<?php echo e(url('/')); ?>">Home</a></li>
			<li class="active">List Pesan Masuk</li>		
		</ol>
	</div>
</div>

<div class="container">
	<div class="col-lg-12">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>#</th>
					<th>Pengirim</th>
					<th>Judul</th>
					<th>created_at</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 1;?>
				<?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Listmessage): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<th scope="row"><?php echo e($i++); ?></th>
					<td><?php echo e($Listmessage->username); ?></td>
					<td><a href="<?php echo e(url('message/inbox/' . $Listmessage->id)); ?>"><?php echo e($Listmessage->title); ?></a></td>
					<td><?php echo e($Listmessage->created_at); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>